import React, { useEffect, useState, useRef } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Platform,
  Animated,
} from "react-native";
import { useLocalSearchParams, useRouter } from "expo-router";
import PromptView from "./PromptView";
import Screen from "./model/Screen";
import { SafeAreaView } from "react-native-safe-area-context";
import IntroView from "./IntroView";
import { sleep101 } from "./model/sleep101";

interface Course {
  screens: Screen[];
}

// Define course assets with their paths
const courseAssets: { [key: string]: Course } = {
  sleep101: sleep101,
  // Add more courses as needed
};

export default function Index() {
  const { courseName } = useLocalSearchParams<{ courseName: string }>();
  const course = courseAssets[courseName];
  const [currentScreenIndex, setCurrentScreenIndex] = useState(0);
  const router = useRouter();
  const progressAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.timing(progressAnim, {
      toValue: (currentScreenIndex + 1) / course.screens.length,
      duration: 500,
      useNativeDriver: false,
    }).start();
  }, [currentScreenIndex]);

  if (!courseName || !courseAssets[courseName]) {
    return (
      <View style={styles.container}>
        <Text style={styles.errorText}>Course not found</Text>
      </View>
    );
  }

  const handleNextScreen = () => {
    if (currentScreenIndex < course.screens.length - 1) {
      setCurrentScreenIndex(currentScreenIndex + 1);
    } else {
      router.push("/");
    }
  };

  const handleIntroTap = () => {
    setCurrentScreenIndex(0); // Set to 0 to start the course screens
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.containerWrapper}>
        <>
          <View style={styles.progressBarContainer}>
            <Animated.View
              style={[
                styles.progressBar,
                {
                  width: progressAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: ["0%", "100%"],
                  }),
                },
              ]}
            />
          </View>
          <TouchableOpacity
            onPress={handleNextScreen}
            style={styles.promptContainer}
          >
            {currentScreenIndex === 0 ? (
              <IntroView
                image={require("../../assets/images/sleep101.png")}
                text={course.screens[currentScreenIndex].header}
              />
            ) : (
              <PromptView screen={course.screens[currentScreenIndex]} />
            )}
          </TouchableOpacity>
        </>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  containerWrapper: {
    width: "100%",
    height: "100%",
    paddingVertical: "4%",
    paddingHorizontal: "4%",
  },
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#141924", // Changed background colo
  },
  promptContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  progressBarContainer: {
    height: 10,
    width: "100%",
    backgroundColor: "#222938",
    borderRadius: 5,
    overflow: "hidden",
  },
  progressBar: {
    height: "100%",
    backgroundColor: "#37C882",
  },
  courseName: {
    fontSize: 24,
    fontWeight: "bold",
  },
  errorText: {
    fontSize: 18,
    color: "red",
  },
});
