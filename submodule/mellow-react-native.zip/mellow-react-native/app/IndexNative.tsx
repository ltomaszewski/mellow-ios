import { useState } from "react";
import { Text, TouchableOpacity, View, StyleSheet } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Image } from "react-native";

interface Course {
  source: string;
  title: string;
  chapterText: string;
  onPressAction?: () => void;
}

export default function IndexNative() {
  const [footerText, setFooterText] = useState({
    chapterText: "Chapter 1",
    titleText: "Sleep 101",
  });

  const courses: Course[] = [
    {
      source: require("../assets/images/learn4.png"),
      title: "Learn 4",
      chapterText: "Chapter 5",
    },
    {
      source: require("../assets/images/learn3.png"),
      title: "Learn 3",
      chapterText: "Chapter 4",
    },
    {
      source: require("../assets/images/learn2.png"),
      title: "Learn 2",
      chapterText: "Chapter 3",
    },
    {
      source: require("../assets/images/learn1.png"),
      title: "Learn 1",
      chapterText: "Chapter 2",
    },
    {
      source: require("../assets/images/sleep101.png"),
      title: "Sleep 101",
      chapterText: "Chapter 1",
      onPressAction: async () => {
        // router.push({
        //   pathname: "/(learn)/Index",
        //   params: { courseName: "sleep101" },
        // });
      },
    },
  ];

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.content}>
        {courses.map((img, index) => {
          let offset = 0;
          if (index === 0) {
            offset = 47 - 15; // First element
          } else if (index === courses.length - 1) {
            offset = 49 - 15; // Last element
          } else {
            offset = Math.abs(index - Math.floor(courses.length / 2)) * 16;
          }
          return (
            <View
              key={index}
              style={[styles.iconStack, { marginLeft: `${offset}%` }]}
            >
              <TouchableOpacity
                style={[styles.image]}
                activeOpacity={1}
                onPress={img.onPressAction}
              >
                <Image
                  style={styles.image}
                  source={img.source}
                  contentFit="contain"
                  transition={1000}
                />
              </TouchableOpacity>
            </View>
          );
        })}
      </View>
      <View style={styles.footer}>
        <Text style={styles.chapterText}>{footerText.chapterText}</Text>
        <Text style={styles.titleText}>{footerText.titleText}</Text>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#282C34",
  },
  content: {
    flex: 1,
    justifyContent: "center",
    paddingLeft: "15%",
  },
  iconStack: {
    marginVertical: 8, // Configurable space between elements
  },
  image: {
    width: 120,
    height: 120,
  },
  footer: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    backgroundColor: "#383D47",
    padding: 16,
  },
  chapterText: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#FFFFFF",
  },
  titleText: {
    fontSize: 16,
    color: "#A0A4AA",
  },
});
