import { useFonts } from "expo-font";
import { SplashScreen, Stack } from "expo-router";
import { useEffect } from "react";

export default function RootLayout() {
  const [loaded] = useFonts({
    GothamRoundedBold: require("../assets/fonts/gothamrnd_bold.otf"),
    GothamRoundedMedium: require("../assets/fonts/gothamrnd_medium.otf"),
    GothamRoundedLight: require("../assets/fonts/gothamrnd_light.otf"),
  });

  useEffect(() => {
    if (loaded) {
      SplashScreen.hideAsync();
    }
  }, [loaded]);

  if (!loaded) {
    return null;
  }

  return (
    <Stack screenOptions={{ headerShown: false }}>
      <Stack.Screen name="index" options={{}} />
    </Stack>
  );
}
